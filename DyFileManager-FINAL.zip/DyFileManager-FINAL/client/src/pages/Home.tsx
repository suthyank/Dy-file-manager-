import { useEffect, useRef, useState } from "react";
import {
  Bot, CalendarDays, Check, Download, FileText, House, Image as ImageIcon,
  Loader2, Mic, MoreVertical, Paintbrush, Paperclip, Play, Plus,
  Send, Share2, Trash2, Video, X, Folder, File, Clock, Lock, Tag, Users
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

type Tab = "home" | "activity" | "automations";
type MediaItem = {
  id: number;
  fileName: string;
  url: string;
  mimeType: string;
  kind: "image" | "video" | "file";
  sizeBytes: number;
  createdAt: Date | string;
};
type ChatMessage = { role: "user" | "assistant"; content: string };
type DyAttachment = { name: string; mimeType: string; sizeBytes: number; base64: string };
type ActivityLog = {
  id: number;
  action: string;
  fileName: string | null;
  fileId: number | null;
  mimeType: string | null;
  sizeBytes: number | null;
  summary: string | null;
  docUrl?: string | null;
  createdAt: Date | string;
};
type AutomationRule = {
  id: number;
  ruleId: string;
  name: string;
  triggers: string;
  keywords: string;
  targetFolder: string;
  enabled: number;
  createdAt: Date | string;
};

const MAX_FILE_BYTES = 100 * 1024 * 1024;

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function timeAgo(date: Date | string) {
  const d = new Date(date);
  const diff = (Date.now() - d.getTime()) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function readAsBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
    reader.onerror = () => reject(new Error("Could not read file"));
    reader.readAsDataURL(file);
  });
}

export default function Home() {
  const inputRef = useRef<HTMLInputElement>(null);
  const dyInputRef = useRef<HTMLInputElement>(null);
  const holdTimer = useRef<number | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);

  const [tab, setTab] = useState<Tab>("home");
  const [navVisible, setNavVisible] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [showDy, setShowDy] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [typeFilter, setTypeFilter] = useState<"all" | "photos" | "videos" | "docs" | "notes">("all");
  const [detailItem, setDetailItem] = useState<MediaItem | null>(null);
  const [query, setQuery] = useState("");
  const [chatInput, setChatInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [dyAttachments, setDyAttachments] = useState<DyAttachment[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(() => new Set());
  const [uploading, setUploading] = useState<string[]>([]);
  const [recording, setRecording] = useState(false);
  const lastScroll = useRef(0);

  const { data: items = [], isLoading, refetch } = trpc.gallery.list.useQuery(undefined, {
    refetchInterval: 4000,
    staleTime: 0,
  });
  const uploadMutation = trpc.gallery.upload.useMutation();
  const removeMutation = trpc.gallery.remove.useMutation();
  const dyMutation = trpc.luma.chat.useMutation();
  const dyInspectMutation = trpc.luma.inspect.useMutation();
  const generateMutation = trpc.luma.generate.useMutation();
  const galleryInspectMutation = trpc.luma.galleryInspect.useMutation();
  const { data: activityLogs = [] } = trpc.gallery.activity.useQuery(undefined, { refetchInterval: 5000 });
  const { data: indexedContext = "" } = trpc.gallery.context.useQuery();
  const { data: automationRules = [] } = trpc.gallery.automations.list.useQuery();
  const toggleAutomation = trpc.gallery.automations.toggle.useMutation();

  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      if (Math.abs(y - lastScroll.current) > 10) {
        setNavVisible(y < lastScroll.current || y < 40);
        lastScroll.current = y;
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const media = (items as MediaItem[]).filter((item) => {
    const nameMatch = item.fileName.toLowerCase().includes(query.toLowerCase());
    if (!nameMatch) return false;
    if (typeFilter === "all") return true;
    if (typeFilter === "photos") return item.kind === "image";
    if (typeFilter === "videos") return item.kind === "video";
    if (typeFilter === "docs")
      return item.kind === "file" && !item.mimeType.startsWith("audio/") && !item.fileName.toLowerCase().includes("note");
    if (typeFilter === "notes")
      return item.kind === "file" && (item.fileName.toLowerCase().includes("note") || item.mimeType.includes("text"));
    return true;
  });

  const uploadFiles = async (files: FileList | File[]) => {
    const valid = Array.from(files).filter((file) => {
      if (file.size > MAX_FILE_BYTES) {
        toast.error(`${file.name} is larger than 100 MB`);
        return false;
      }
      return true;
    });
    if (!valid.length) return;
    setShowAdd(false);
    setUploading(valid.map((f) => f.name));
    for (const file of valid) {
      try {
        const base64 = await readAsBase64(file);
        await uploadMutation.mutateAsync({
          fileName: file.name,
          mimeType: file.type || "application/octet-stream",
          sizeBytes: file.size,
          base64,
        });
        await refetch();
        toast.success("Added");
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Upload failed");
      } finally {
        setUploading((prev) => prev.filter((n) => n !== file.name));
      }
    }
  };

  const startRecording = async () => {
    if (recording) {
      recorderRef.current?.stop();
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      toast.error("Recording not supported");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size) chunks.push(e.data);
      };
      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        setRecording(false);
        recorderRef.current = null;
        void uploadFiles([
          new File(chunks, `recording-${Date.now()}.webm`, { type: recorder.mimeType || "audio/webm" }),
        ]);
      };
      recorderRef.current = recorder;
      recorder.start();
      setRecording(true);
      setShowAdd(false);
      toast("Recording… tap mic again to save");
    } catch {
      toast.error("Mic permission denied");
    }
  };

  const openItem = (item: MediaItem) => {
    if (selectedIds.size) {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        if (next.has(item.id)) next.delete(item.id);
        else next.add(item.id);
        return next;
      });
    } else {
      setDetailItem(item);
    }
  };

  const beginHold = (item: MediaItem) => {
    holdTimer.current = window.setTimeout(() => {
      setSelectedIds((prev) => new Set(prev).add(item.id));
      toast("Selected — tap more or use bar");
    }, 480);
  };
  const endHold = () => {
    if (holdTimer.current) window.clearTimeout(holdTimer.current);
    holdTimer.current = null;
  };

  const deleteItem = async (item: MediaItem) => {
    try {
      await removeMutation.mutateAsync({ id: item.id, fileName: item.fileName });
      setDetailItem(null);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(item.id);
        return next;
      });
      await refetch();
      toast.success("Deleted");
    } catch {
      toast.error("Could not delete");
    }
  };

  const deleteSelected = async () => {
    if (!selectedIds.size) return;
    const toDelete = media.filter((e) => selectedIds.has(e.id));
    await Promise.all(toDelete.map((item) => removeMutation.mutateAsync({ id: item.id, fileName: item.fileName })));
    setSelectedIds(new Set());
    await refetch();
    toast.success("Deleted");
  };

  const addDyAttachments = async (files: FileList | File[]) => {
    const next: DyAttachment[] = [];
    for (const file of Array.from(files).slice(0, 8)) {
      if (file.size > MAX_FILE_BYTES) {
        toast.error(`${file.name} too large`);
        continue;
      }
      next.push({
        name: file.name,
        mimeType: file.type || "application/octet-stream",
        sizeBytes: file.size,
        base64: await readAsBase64(file),
      });
    }
    setDyAttachments((prev) => [...prev, ...next].slice(0, 8));
  };

  const sendToDy = async (text = chatInput) => {
    const clean = text.trim();
    if (!clean && !dyAttachments.length) return;
    const shown = clean || `Inspect ${dyAttachments.map((f) => f.name).join(", ")}`;
    const next = [...messages, { role: "user" as const, content: shown }];
    setMessages(next);
    setChatInput("");
    try {
      if (clean.toLowerCase().startsWith("/image ") || clean.toLowerCase().startsWith("gen ")) {
        const prompt = clean.replace(/^\/image\s+|^gen\s+/i, "").trim();
        const result = await generateMutation.mutateAsync({ prompt });
        setMessages([
          ...next,
          { role: "assistant", content: result.url ? `Generated:\n${result.url}` : "Image generated." },
        ]);
      } else if (clean.toLowerCase().startsWith("/scan") || clean.toLowerCase().includes("read my")) {
        const result = await galleryInspectMutation.mutateAsync({
          prompt: clean.replace(/^\/scan\s*/i, "").trim() || "Describe the most relevant uploaded files.",
        });
        setMessages([...next, { role: "assistant", content: result.content }]);
      } else if (dyAttachments.length) {
        const result = await dyInspectMutation.mutateAsync({
          prompt: clean || "Read and summarize these files carefully. Extract key content.",
          context: indexedContext,
          attachments: dyAttachments,
        });
        setMessages([...next, { role: "assistant", content: result.content }]);
      } else {
        const result = await dyMutation.mutateAsync({
          messages: next,
          context: indexedContext || `${items.length} files in gallery`,
        });
        setMessages([...next, { role: "assistant", content: result.content }]);
      }
      setDyAttachments([]);
    } catch (error) {
      setMessages([
        ...next,
        {
          role: "assistant",
          content: error instanceof Error ? error.message : "Dy could not process this right now.",
        },
      ]);
    }
  };

  return (
    <main className="min-h-screen bg-[#f5f7f0] text-[#1a2119] font-sans">
      <header
        className={`fixed inset-x-0 top-0 z-40 bg-[#dce8d4]/95 backdrop-blur-xl px-4 pt-4 pb-3 transition-transform duration-300 ${
          navVisible ? "translate-y-0" : "-translate-y-full"
        }`}
      >
        <div className="mx-auto max-w-[480px] flex items-center gap-2.5">
          <button
            onClick={() => setShowDy(true)}
            className="flex min-w-0 flex-1 items-center gap-2.5 rounded-full bg-white px-4 py-3.5 shadow-sm"
          >
            <svg className="h-5 w-5 text-[#5a6b58] shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <span className="truncate text-[15px] text-[#3d4a3c]">Ask Dy</span>
          </button>
          <button
            onClick={() => setShowAdd(true)}
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white shadow-sm"
            aria-label="Add"
          >
            <Plus className="h-6 w-6 text-[#1a2119]" />
          </button>
          <button
            onClick={() => setShowProfile(true)}
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#6b4538] text-lg font-semibold text-white shadow-sm"
            aria-label="Profile"
          >
            R
          </button>
        </div>
      </header>

      <section className="mx-auto max-w-[480px] px-4 pb-36 pt-24">
        <div className="mb-4 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {(
            [
              ["all", "All", Folder],
              ["photos", "Photos", ImageIcon],
              ["videos", "Videos", Video],
              ["docs", "Docs", FileText],
              ["notes", "Notes", File],
            ] as const
          ).map(([value, label, Icon]) => (
            <button
              key={value}
              onClick={() => setTypeFilter(value)}
              className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-[13px] font-medium transition ${
                typeFilter === value
                  ? "bg-[#c5dbc0] text-[#1a2a19]"
                  : "bg-white text-[#5a6b58] border border-[#e0e6d8]"
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              {label}
            </button>
          ))}
        </div>

        {tab === "home" && (
          <>
            {uploading.length > 0 && (
              <div className="mb-3 flex items-center gap-2 rounded-2xl bg-[#1a2a19] px-4 py-2.5 text-sm text-white">
                <Loader2 className="h-4 w-4 animate-spin" /> Uploading {uploading.length}…
              </div>
            )}

            {selectedIds.size > 0 && (
              <div className="fixed inset-x-4 bottom-24 z-30 mx-auto flex max-w-[450px] items-center justify-between rounded-full bg-[#c5dbc0] px-4 py-2.5 text-sm shadow-lg">
                <span className="font-medium">{selectedIds.size} selected</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => setSelectedIds(new Set())}
                    className="rounded-full bg-white px-3.5 py-1.5 text-xs font-medium"
                  >
                    Clear
                  </button>
                  <button
                    onClick={() => void deleteSelected()}
                    className="rounded-full bg-[#c44a3a] px-3.5 py-1.5 text-xs font-medium text-white"
                  >
                    Delete
                  </button>
                </div>
              </div>
            )}

            {isLoading ? (
              <div className="grid grid-cols-2 gap-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="aspect-[0.85] animate-pulse rounded-2xl bg-[#e8efe4]" />
                ))}
              </div>
            ) : media.length ? (
              <div className="grid grid-cols-2 gap-3">
                {media.map((item) => (
                  <article
                    key={item.id}
                    className={`relative overflow-hidden rounded-2xl bg-white shadow-[0_2px_10px_rgba(40,60,30,0.06)] ${
                      selectedIds.has(item.id) ? "ring-2 ring-[#7a9e72]" : ""
                    }`}
                    onPointerDown={() => beginHold(item)}
                    onPointerUp={endHold}
                    onPointerCancel={endHold}
                    onContextMenu={(e) => e.preventDefault()}
                  >
                    <button onClick={() => openItem(item)} className="block w-full text-left">
                      <div className="flex items-start justify-between px-3 pt-3 pb-1">
                        <div className="min-w-0 flex-1">
                          <h3 className="truncate text-[14px] font-bold text-[#1a2119] leading-tight">
                            {item.fileName.replace(/\.[^/.]+$/, "")}
                          </h3>
                          <p className="mt-0.5 text-[11px] text-[#6b7a68]">
                            {formatBytes(item.sizeBytes)} · Last edited {timeAgo(item.createdAt)}
                          </p>
                        </div>
                        <button
                          onClick={(e) => e.stopPropagation()}
                          className="ml-1 mt-0.5 p-1 text-[#6b7a68]"
                        >
                          <MoreVertical className="h-4 w-4" />
                        </button>
                      </div>

                      <div className="relative mx-2 mb-2 aspect-[1.1] overflow-hidden rounded-xl bg-[#f0f4ec]">
                        {item.kind === "image" && (
                          <img src={item.url} alt="" loading="lazy" className="h-full w-full object-cover" />
                        )}
                        {item.kind === "video" && (
                          <div className="relative h-full w-full">
                            <video src={item.url} className="h-full w-full object-cover" muted playsInline preload="metadata" />
                            <span className="absolute inset-0 flex items-center justify-center">
                              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-black/40 text-white">
                                <Play className="h-5 w-5 fill-current" />
                              </span>
                            </span>
                          </div>
                        )}
                        {item.kind === "file" && (
                          <div className="flex h-full flex-col items-center justify-center gap-2 p-3">
                            <FileText className="h-10 w-10 text-[#7a8f78]" strokeWidth={1.5} />
                            <span className="text-[10px] font-medium text-[#6b7a68] truncate max-w-full px-2">
                              {item.fileName}
                            </span>
                          </div>
                        )}
                      </div>

                      <div className="absolute bottom-3 right-3">
                        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/90 text-[#5a6b58] shadow-sm">
                          <Share2 className="h-3.5 w-3.5" />
                        </span>
                      </div>

                      {selectedIds.has(item.id) && (
                        <span className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-[#6c8f68] text-white">
                          <Check className="h-3.5 w-3.5" />
                        </span>
                      )}
                    </button>
                  </article>
                ))}
              </div>
            ) : (
              <div className="flex min-h-[420px] flex-col items-center justify-center text-[#7a8a78]">
                <Folder className="mb-3 h-12 w-12 opacity-40" />
                <p className="text-sm">No files yet. Tap + to add.</p>
              </div>
            )}
          </>
        )}

        {tab === "activity" && <ActivityPanel logs={activityLogs as ActivityLog[]} />}
        {tab === "automations" && (
          <AutomationPanel
            rules={automationRules as AutomationRule[]}
            onToggle={(rule, enabled) => void toggleAutomation.mutateAsync({ id: rule.id, enabled })}
          />
        )}
      </section>

      <input
        ref={inputRef}
        type="file"
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files) void uploadFiles(e.target.files);
          e.currentTarget.value = "";
        }}
      />
      <input
        ref={dyInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files) void addDyAttachments(e.target.files);
          e.currentTarget.value = "";
        }}
      />

      <nav
        className={`fixed inset-x-0 bottom-0 z-40 border-t border-[#e4eadc] bg-[#f5f7f0]/95 backdrop-blur-xl px-6 pb-5 pt-2.5 transition-transform duration-300 ${
          navVisible ? "translate-y-0" : "translate-y-full"
        }`}
      >
        <div className="mx-auto flex max-w-[480px] items-end justify-between">
          <NavButton active={tab === "home"} icon={<House className="h-5 w-5" />} label="Home" onClick={() => setTab("home")} />
          <NavButton active={tab === "activity"} icon={<CalendarDays className="h-5 w-5" />} label="Activity" onClick={() => setTab("activity")} />
          <NavButton active={tab === "automations"} icon={<Share2 className="h-5 w-5" />} label="Automations" onClick={() => setTab("automations")} />
        </div>
      </nav>

      {showAdd && (
        <Sheet onClose={() => setShowAdd(false)}>
          <h2 className="mb-4 text-lg font-semibold">Add files</h2>
          <div className="grid grid-cols-4 gap-3">
            {[
              ["Photo", ImageIcon],
              ["Video", Video],
              ["File", FileText],
              [recording ? "Stop" : "Record", Mic],
            ].map(([label, Icon], idx) => (
              <button
                key={String(label)}
                onClick={() =>
                  idx === 3 ? void startRecording() : (setShowAdd(false), inputRef.current?.click())
                }
                className="flex flex-col items-center gap-2 rounded-2xl bg-[#eaf0e4] p-4 text-xs text-[#3d4a3c]"
              >
                <Icon className="h-6 w-6" />
                <span>{String(label)}</span>
              </button>
            ))}
          </div>
        </Sheet>
      )}

      {showProfile && (
        <Sheet onClose={() => setShowProfile(false)}>
          <div className="flex items-center gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-[#6b4538] text-xl text-white">R</div>
            <div>
              <h2 className="font-semibold">Dy File Manager</h2>
              <p className="text-sm text-[#6b7a68]">Owner profile</p>
            </div>
          </div>
        </Sheet>
      )}

      {detailItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm"
          onClick={() => setDetailItem(null)}
        >
          <div
            className="relative flex max-h-[90vh] w-full max-w-[420px] flex-col overflow-hidden rounded-3xl bg-[#f5f7f0] shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button onClick={() => setDetailItem(null)} className="absolute right-3 top-3 z-10 rounded-full bg-white/90 p-2">
              <X className="h-5 w-5" />
            </button>
            <div className="max-h-[70vh] overflow-auto bg-[#e8efe4]">
              {detailItem.kind === "image" && (
                <img src={detailItem.url} alt="" className="mx-auto max-h-[70vh] w-full object-contain" />
              )}
              {detailItem.kind === "video" && (
                <video src={detailItem.url} controls autoPlay playsInline className="max-h-[70vh] w-full" />
              )}
              {detailItem.kind === "file" && (
                <div className="flex min-h-48 flex-col items-center justify-center gap-3 p-8">
                  <FileText className="h-14 w-14 text-[#6c8f68]" />
                  <p className="text-sm font-medium">{detailItem.fileName}</p>
                  <a href={detailItem.url} download className="rounded-full bg-[#c5dbc0] px-5 py-2 text-sm font-medium">
                    Download
                  </a>
                </div>
              )}
            </div>
            <div className="flex items-center gap-3 p-4">
              <a href={detailItem.url} download className="flex flex-1 items-center justify-center gap-2 rounded-full bg-[#c5dbc0] py-3 text-sm font-medium">
                <Download className="h-4 w-4" /> Download
              </a>
              <button onClick={() => void deleteItem(detailItem)} className="rounded-full bg-[#fde8e4] p-3 text-[#c44a3a]">
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {showDy && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/25 backdrop-blur-[2px]" onClick={() => setShowDy(false)}>
          <div
            className="mx-auto flex w-full max-w-[480px] flex-col rounded-t-[28px] bg-[#f8faf4] shadow-2xl"
            style={{ maxHeight: "78vh" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-center pt-3 pb-1">
              <div className="h-1 w-10 rounded-full bg-[#c8d4c0]" />
            </div>
            <div className="flex items-center gap-2.5 px-5 pb-3 pt-1">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#e4efdc]">
                <Bot className="h-5 w-5 text-[#3d5a38]" />
              </div>
              <div>
                <p className="text-[15px] font-semibold text-[#1a2119]">Ask Dy</p>
                <p className="text-[12px] text-[#6b7a68]">
                  {dyMutation.isPending || dyInspectMutation.isPending || generateMutation.isPending ? "Thinking…" : "Listening…"}
                </p>
              </div>
              <button onClick={() => setShowDy(false)} className="ml-auto p-1">
                <X className="h-5 w-5 text-[#6b7a68]" />
              </button>
            </div>

            <div className="flex-1 space-y-3 overflow-y-auto px-5 pb-3" style={{ minHeight: 120 }}>
              {messages.length === 0 && (
                <p className="py-6 text-center text-[13px] text-[#7a8a78] leading-relaxed">
                  Try: “Read my Sanskrit notes” or “Gen minimalist robot”
                </p>
              )}
              {messages.map((m, i) => (
                <div
                  key={i}
                  className={`max-w-[88%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-[13px] leading-relaxed ${
                    m.role === "user" ? "ml-auto bg-[#c5dbc0] text-[#1a2a19]" : "bg-white text-[#1a2119] shadow-sm"
                  }`}
                >
                  {m.content}
                </div>
              ))}
              {(dyMutation.isPending || dyInspectMutation.isPending || generateMutation.isPending) && (
                <Loader2 className="h-4 w-4 animate-spin text-[#6b7a68]" />
              )}
            </div>

            {dyAttachments.length > 0 && (
              <div className="flex gap-2 overflow-x-auto border-t border-[#e4eadc] px-4 py-2">
                {dyAttachments.map((f, i) => (
                  <button
                    key={`${f.name}-${i}`}
                    onClick={() => setDyAttachments((p) => p.filter((_, idx) => idx !== i))}
                    className="shrink-0 rounded-full bg-[#c5dbc0] px-3 py-1.5 text-[11px]"
                  >
                    {f.name.slice(0, 18)} ×
                  </button>
                ))}
              </div>
            )}

            <div className="border-t border-[#e4eadc] px-4 pb-5 pt-3">
              <div className="flex items-center gap-2 rounded-full border border-[#d4e0cc] bg-white px-3 py-2">
                <input
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      void sendToDy();
                    }
                  }}
                  placeholder="Ask about a file or generate an image…"
                  className="min-w-0 flex-1 bg-transparent text-[14px] outline-none placeholder:text-[#8a9a88]"
                />
                <button type="button" onClick={() => dyInputRef.current?.click()} className="p-1.5 text-[#5a6b58]" title="Attach file">
                  <Paperclip className="h-4 w-4" />
                </button>
                <button type="button" onClick={() => void startRecording()} className="p-1.5 text-[#5a6b58]">
                  <Mic className="h-4 w-4" />
                </button>
                <button onClick={() => void sendToDy()} className="flex h-8 w-8 items-center justify-center rounded-full bg-[#6c8f68] text-white">
                  <Send className="h-4 w-4" />
                </button>
              </div>

              <div className="mt-2.5 flex gap-2">
                <button
                  onClick={() => {
                    setChatInput("Read the attached file");
                    dyInputRef.current?.click();
                  }}
                  className="flex items-center gap-1.5 rounded-full bg-[#eaf0e4] px-3 py-1.5 text-[12px] text-[#3d4a3c]"
                >
                  <FileText className="h-3.5 w-3.5" /> Read File
                </button>
                <button
                  onClick={() => setChatInput("/image ")}
                  className="flex items-center gap-1.5 rounded-full bg-[#eaf0e4] px-3 py-1.5 text-[12px] text-[#3d4a3c]"
                >
                  <Paintbrush className="h-3.5 w-3.5" /> Gen Image
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

function ActivityPanel({ logs }: { logs: ActivityLog[] }) {
  const now = new Date();
  const todayLogs = logs.filter((l) => new Date(l.createdAt).toDateString() === now.toDateString());

  const getIcon = (action: string) => {
    const a = action.toLowerCase();
    if (a.includes("upload") || a.includes("added")) return <Download className="h-4 w-4" />;
    if (a.includes("edit") || a.includes("note")) return <FileText className="h-4 w-4" />;
    if (a.includes("shar")) return <Share2 className="h-4 w-4" />;
    if (a.includes("delet")) return <Trash2 className="h-4 w-4" />;
    return <Clock className="h-4 w-4" />;
  };

  const getBg = (action: string) => {
    const a = action.toLowerCase();
    if (a.includes("delet")) return "bg-[#fde8e4]";
    return "bg-[#eef2e8]";
  };

  return (
    <div>
      <div className="mb-1 flex items-center justify-between">
        <h1 className="text-[26px] font-bold tracking-tight text-[#1a2119]">Activity Log</h1>
        <button className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#eaf0e4]">
          <CalendarDays className="h-4 w-4 text-[#5a6b58]" />
        </button>
      </div>
      <p className="mb-5 text-[15px] text-[#5a6b58]">
        {now.toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" })}
      </p>

      <div className="space-y-3">
        {(todayLogs.length ? todayLogs : logs.slice(0, 8)).map((log) => (
          <div key={log.id} className={`flex items-start gap-3 rounded-2xl p-4 ${getBg(log.action)}`}>
            <div className="min-w-0 flex-1">
              <p className="text-[15px] font-semibold text-[#1a2119]">{log.action}</p>
              {log.fileName && (
                <p className="mt-0.5 text-[13px] text-[#4a5a48]">
                  File: {log.fileName}
                  {log.sizeBytes ? ` · size: ${formatBytes(log.sizeBytes)}` : ""}
                </p>
              )}
              {log.summary && !log.fileName && (
                <p className="mt-0.5 text-[13px] text-[#4a5a48]">{log.summary}</p>
              )}
              <p className="mt-1 text-[12px] text-[#7a8a78]">
                {new Date(log.createdAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
              </p>
            </div>
            <div className="mt-0.5 text-[#6b7a68]">{getIcon(log.action)}</div>
          </div>
        ))}
        {logs.length === 0 && (
          <div className="rounded-2xl bg-[#eef2e8] p-8 text-center text-sm text-[#7a8a78]">No activity yet</div>
        )}
      </div>
    </div>
  );
}

function AutomationPanel({
  rules,
  onToggle,
}: {
  rules: AutomationRule[];
  onToggle: (rule: AutomationRule, enabled: boolean) => void;
}) {
  const activeCount = rules.filter((r) => r.enabled).length;

  const displayRules =
    rules.length > 0
      ? rules
      : [
          {
            id: 1,
            ruleId: "auto-tag",
            name: "AI Auto-Tagging Documents",
            triggers: "PDF/Text",
            keywords: "subject (e.g. Sanskrit, Maths)",
            targetFolder: "auto-file based on subject",
            enabled: 1,
            createdAt: new Date().toISOString(),
          },
          {
            id: 2,
            ruleId: "encrypt",
            name: "Auto-Encryption for Personal Files",
            triggers: "Private tagged",
            keywords: "extra password layer",
            targetFolder: "Private",
            enabled: 1,
            createdAt: new Date().toISOString(),
          },
          {
            id: 3,
            ruleId: "encrypt2",
            name: "Auto-Encryption for Personal Files",
            triggers: "Private tagged",
            keywords: "extra password layer",
            targetFolder: "Private",
            enabled: 1,
            createdAt: new Date().toISOString(),
          },
          {
            id: 4,
            ruleId: "sync",
            name: "Schedule Cloud Sync",
            triggers: "Manual files",
            keywords: "chosen files",
            targetFolder: "sync at 2:00 AM",
            enabled: 1,
            createdAt: new Date().toISOString(),
          },
        ];

  const getRuleIcon = (name: string) => {
    if (name.toLowerCase().includes("tag") || name.toLowerCase().includes("ai")) return <Tag className="h-4 w-4" />;
    if (name.toLowerCase().includes("encrypt")) return <Lock className="h-4 w-4" />;
    if (name.toLowerCase().includes("sync")) return <Clock className="h-4 w-4" />;
    return <Users className="h-4 w-4" />;
  };

  return (
    <div>
      <div className="mb-4 flex gap-2 overflow-x-auto">
        <span className="shrink-0 rounded-full bg-[#e4efdc] px-3.5 py-1.5 text-[13px] font-medium text-[#2a3a28]">
          Active Tasks: {activeCount || 3}
        </span>
        <span className="shrink-0 rounded-full bg-[#e4efdc] px-3.5 py-1.5 text-[13px] font-medium text-[#2a3a28]">
          Storage Optimization: ON
        </span>
      </div>

      <h2 className="mb-3 text-[18px] font-bold text-[#1a2119]">Active Automations ({displayRules.length})</h2>

      <div className="grid grid-cols-2 gap-3 mb-6">
        {displayRules.map((rule) => (
          <article key={rule.id} className="relative flex flex-col rounded-2xl bg-white p-3.5 shadow-[0_2px_8px_rgba(40,60,30,0.05)]">
            <div className="mb-2 flex items-start justify-between">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#eaf0e4] text-[#4a6a45]">
                {getRuleIcon(rule.name)}
              </div>
              <button className="p-0.5 text-[#8a9a88]">
                <MoreVertical className="h-4 w-4" />
              </button>
            </div>
            <h3 className="text-[13px] font-semibold leading-snug text-[#1a2119] line-clamp-2">{rule.name}</h3>
            <p className="mt-1 flex-1 text-[11px] leading-snug text-[#6b7a68] line-clamp-3">
              {rule.triggers} · {rule.keywords}
            </p>
            <div className="mt-3 flex items-center justify-between">
              <span className="text-[10px] text-[#8a9a88]">{rule.targetFolder}</span>
              <button
                onClick={() => onToggle(rule, !rule.enabled)}
                className={`relative h-6 w-11 rounded-full transition ${rule.enabled ? "bg-[#6c8f68]" : "bg-[#c8d4c0]"}`}
              >
                <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition ${rule.enabled ? "left-5" : "left-0.5"}`} />
              </button>
            </div>
          </article>
        ))}
      </div>

      <h2 className="mb-3 text-[16px] font-semibold text-[#1a2119]">Create New Automation</h2>
      <div className="flex gap-3">
        <button className="flex h-14 w-14 flex-col items-center justify-center rounded-2xl bg-[#e4efdc] text-[#3d5a38]">
          <Plus className="h-6 w-6" />
        </button>
        <button className="flex flex-1 flex-col items-center justify-center gap-1 rounded-2xl bg-[#eaf0e4] py-3 text-[12px] text-[#4a5a48]">
          <Tag className="h-5 w-5" />
          Tagging
        </button>
        <button className="flex flex-1 flex-col items-center justify-center gap-1 rounded-2xl bg-[#eaf0e4] py-3 text-[12px] text-[#4a5a48]">
          <Lock className="h-5 w-5" />
          Security
        </button>
        <button className="flex flex-1 flex-col items-center justify-center gap-1 rounded-2xl bg-[#eaf0e4] py-3 text-[12px] text-[#4a5a48]">
          <Share2 className="h-5 w-5" />
          Sharing
        </button>
      </div>
    </div>
  );
}

function Sheet({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end bg-black/30 backdrop-blur-sm" onClick={onClose}>
      <div className="mx-auto w-full max-w-[480px] rounded-t-[28px] bg-[#f8faf4] p-5 pb-8 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex justify-center">
          <div className="h-1 w-10 rounded-full bg-[#c8d4c0]" />
        </div>
        {children}
      </div>
    </div>
  );
}

function NavButton({
  active,
  icon,
  label,
  onClick,
}: {
  active: boolean;
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button onClick={onClick} className="flex min-w-[80px] flex-col items-center gap-1 text-[#5a6b58]">
      <span className={`flex h-11 w-20 items-center justify-center rounded-full transition ${active ? "bg-[#c5dbc0] text-[#1a2a19]" : "bg-transparent"}`}>
        {icon}
      </span>
      <span className={`text-[12px] ${active ? "font-semibold text-[#1a2a19]" : ""}`}>{label}</span>
    </button>
  );
}
